/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BT3;

/**
 *
 * @author WIN
 */
public class MonHoc {
    private String mamon, tenmon, hinhthucthi;

    public MonHoc(String mamon, String tenmon, String hinhthucthi) {
        this.mamon = mamon;
        this.tenmon = tenmon;
        this.hinhthucthi = hinhthucthi;
    }

    public String getMamon() {
        return mamon;
    }

    public String getTenmon() {
        return tenmon;
    }

    public String getHinhthucthi() {
        return hinhthucthi;
    }
    
}
