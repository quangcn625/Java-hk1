/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TN02012_TinhLuong;

/**
 *
 * @author WIN
 */
public class PhongBan {
    private String maphong, tenphong;

    public PhongBan(String maphong, String tenphong) {
        this.maphong = maphong;
        this.tenphong = tenphong;
    }

    public String getMaphong() {
        return maphong;
    }

    public String getTenphong() {
        return tenphong;
    }
    
}