/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package J07027_QuanLyBaiTapNhom;

/**
 *
 * @author WIN
 */
public class SinhVien {
    private String maSV;
    private String nameSV;
    private String sdt;

    public SinhVien(String maSV, String nameSV, String sdt) {
        this.maSV = maSV;
        this.nameSV = nameSV;
        this.sdt = sdt;
    }

    public String getMaSV() {
        return maSV;
    }

    public String getNameSV() {
        return nameSV;
    }

    public String getSdt() {
        return sdt;
    }
    
}
