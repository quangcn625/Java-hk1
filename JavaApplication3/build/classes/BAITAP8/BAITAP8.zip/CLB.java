/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BAITAP8;

/**
 *
 * @author WIN
 */
class CLB {
    protected String idCLB,nameCLB;
    protected int giaVe;

    public CLB(String idCLB, String name, int giaVe) {
        this.idCLB = idCLB;
        this.nameCLB = name;
        this.giaVe = giaVe;
    }
}
