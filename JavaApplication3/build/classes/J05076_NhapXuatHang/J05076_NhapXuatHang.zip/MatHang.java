/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package J05076_NhapXuatHang;

/**
 *
 * @author WIN
 */
public class MatHang {
    protected String ma, name, xeploai;

    public MatHang(String ma, String name, String xeploai) {
        this.ma = ma;
        this.name = name;
        this.xeploai = xeploai;
    }
}
