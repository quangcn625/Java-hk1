/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package TEST;

/**
 *
 * @author WIN
 */
import java.util.*;
import java.io.*;

public class Main {

    /**
     * @param args the command line arguments
     */
    static int dayso[], a[], n;
    static boolean ok;
    
    static void sinh(){
        int i = n;
        while(a[i] == 1 && i > 0) i--;
        if(i == 0){
            ok = false;
            return;
        }
        else{
            a[i]++;
            for(int j=i+1; j<=n; j++) a[j] = 0;
        }
    }
    
    public static void main(String[] args) throws IOException {
        WordSet ws = new WordSet("VANBAN.in");
        System.out.println(ws);
    }
    
}

