/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package J07038_DanhSachThucTap_3;

/**
 *
 * @author WIN
 */
public class DN {
    private String maDN, nameDN;
    private int soSV;

    public DN(String maDN, String nameDN, int soSV) {
        this.maDN = maDN;
        this.nameDN = nameDN;
        this.soSV = soSV;
    }

    public String getMaDN() {
        return maDN;
    }

    public String getNameDN() {
        return nameDN;
    }

    public int getSoSV() {
        return soSV;
    }
    
}
