/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package J05070_CauLacBoBongDa_2;

/**
 *
 * @author WIN
 */
public class CLB {
    protected String maCLB;
    protected String nameCLB;
    protected long giava;

    public CLB(String maCLB, String nameCLB, long giava) {
        this.maCLB = maCLB;
        this.nameCLB = nameCLB;
        this.giava = giava;
    }
}
