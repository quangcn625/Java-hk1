/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package J07036_BangDiemTheoLop;

/**
 *
 * @author WIN
 */
public class MonHoc {
    private String mamon, tenmon, sotinchi;

    public MonHoc(String mamon, String tenmon, String sotinchi) {
        this.mamon = mamon;
        this.tenmon = tenmon;
        this.sotinchi = sotinchi;
    }

    public String getMamon() {
        return mamon;
    }

    public String getTenmon() {
        return tenmon;
    }
    
}

