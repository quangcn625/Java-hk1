/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package J05074_DiemDanh1;

import java.util.ArrayList;

/**
 *
 * @author WIN
 */
public class SinhVien {
    protected String msv, name, lop;

    public SinhVien(String msv, String name, String lop) {
        this.msv = msv;
        this.name = name;
        this.lop = lop;
    }

    public String getMsv() {
        return msv;
    }
   
}
