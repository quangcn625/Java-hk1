/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package J06007_BangTinhGioChuan;

/**
 *
 * @author WIN
 */
public class MonHoc {
    private String mamon, tenmon;

    public MonHoc(String mamon, String tenmon) {
        this.mamon = mamon;
        this.tenmon = tenmon;
    }

    public String getMamon() {
        return mamon;
    }

    public String getTenmon() {
        return tenmon;
    }
    
}
